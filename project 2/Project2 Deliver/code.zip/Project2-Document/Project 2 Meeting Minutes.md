# Meeting Minutes
##### Date: 25 May 2018

##### Duration: 1 hours

##### Attentance: Yirun Pan, Ning Kang, Nannan Gu, Wenyi Zhao

0. Report finalise
1. Usage & Test cases finalise



##### Date: 21 May 2018

##### Duration: 2 hours

##### Attentance: Yirun Pan, Ning Kang, Nannan Gu, Wenyi Zhao

0. Testing results discussion
1. Discuss the final report structure
2. Documentation tasks assignment


##### Date: 17 May 2018

##### Duration: 2 hours

##### Attentance: Yirun Pan, Ning Kang, Nannan Gu, Wenyi Zhao

Meeting minutes:

0. Task process tracing
1. Simple overall testing of current project by task owners
2. Test cases designing
3. Test cases tasks assignments
4. Useless code clearance 


##### Date: 10 May 2018

##### Duration: 2 hours

##### Attentance: Yirun Pan, Ning Kang, Nannan Gu, Wenyi Zhao


Meeting minutes:

0. Finalise the refactoring of the old system 
1. Design some new protocals to achieve the aims
2. Assign tasks

##### Date: 03 May 2018

##### Duration: 2 hours

##### Attentance: Yirun Pan, Ning Kang, Nannan Gu, Wenyi Zhao


Meeting minutes:

0. Discuss overview requirements of this project 
1. Discuss how to realize the aims and the possible new protocals 
2. Discuss how to ensure high availability and eventual consistency
3. Design a new architecture of the whole system to meet the new requirements
4. Assign system refactoring tasks