import java.util.Calendar;

/**
 * test
 * <p>
 * Author Ning Kang
 * Date 9/4/18
 */

public class test {

	public static void main(String[] argv) {
		System.out.println(Calendar.getInstance().getTime());

	}
}
